
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Problem } from './components/Problem';
import { Story } from './components/Story';
import { Philosophy } from './components/Philosophy';
import { USP } from './components/USP';
import { Modules } from './components/Modules';
import { Travel } from './components/Travel';
import { Testimonials } from './components/Testimonials';
import { Awards } from './components/Awards';
import { Transformation } from './components/Transformation';
import { Process } from './components/Process';
import { Webinar } from './components/Webinar';
import { LeadForm } from './components/LeadForm';
import { FAQ } from './components/FAQ';
import { Footer } from './components/Footer';
import { FloatingCTA } from './components/FloatingCTA';
import { WhatsAppButton } from './components/WhatsAppButton';
import { ScrollProgress } from './components/ScrollProgress';

function App() {
  const [showFloatingCTA, setShowFloatingCTA] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      const totalHeight = document.documentElement.scrollHeight;
      
      // Show CTA after 30% scroll
      setShowFloatingCTA(scrollPosition > windowHeight * 0.3);
      
      // Hide CTA when form is likely in view (bottom 500px)
      if (scrollPosition > totalHeight - windowHeight - 800) {
        setShowFloatingCTA(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white overflow-x-hidden selection:bg-[#00d4ff] selection:text-black">
      <ScrollProgress />
      <Header />
      
      <main>
        <Hero />
        <Problem />
        <Story />
        <Philosophy />
        <USP />
        <Modules />
        <Travel />
        <Testimonials />
        <Awards />
        <Transformation />
        <Process />
        <Webinar />
        <LeadForm />
        <FAQ />
      </main>

      <Footer />
      
      {showFloatingCTA && <FloatingCTA />}
      <WhatsAppButton />
    </div>
  );
}

export default App;
