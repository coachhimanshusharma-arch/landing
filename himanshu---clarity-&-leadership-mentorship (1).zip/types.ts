
export interface Milestone {
  id: string;
  title: string;
  description: string;
  phase: string;
}

export interface Module {
  id: number;
  title: string;
  description: string;
  points: string[];
}

export interface Testimonial {
  name: string;
  location: string;
  text: string;
  rating: number;
}
