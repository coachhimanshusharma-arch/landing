
import React, { useState, useEffect, useCallback } from 'react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const testimonials = [
    {
      name: "Priya M.",
      loc: "Jaipur, Student",
      text: "Himanshu provided the clarity I hadn't found in two years. Now I understand how to work effectively without any pressure.",
      rating: 5
    },
    {
      name: "Amit S.",
      loc: "Mumbai, Professional",
      text: "No pressure, no hype. Just genuine guidance. Finally, someone explained the truth about network marketing and its systems.",
      rating: 5
    },
    {
      name: "Sneha R.",
      loc: "Bangalore, Entrepreneur",
      text: "I learned modern tools and funnels. This approach is so different from traditional methods. The focus on personal branding is amazing.",
      rating: 5
    },
    {
      name: "Vikram P.",
      loc: "Lucknow, Graduate",
      text: "My confidence has grown tremendously when speaking with my team. Leadership skills are developing through step-by-step guidance.",
      rating: 5
    }
  ];

  const handleNext = useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);
    setTimeout(() => {
      setActiveIdx((p) => (p + 1) % testimonials.length);
      setIsAnimating(false);
    }, 300);
  }, [isAnimating, testimonials.length]);

  const handlePrev = useCallback(() => {
    if (isAnimating) return;
    setIsAnimating(true);
    setTimeout(() => {
      setActiveIdx((p) => (p - 1 + testimonials.length) % testimonials.length);
      setIsAnimating(false);
    }, 300);
  }, [isAnimating, testimonials.length]);

  const handleDotClick = (index: number) => {
    if (isAnimating || index === activeIdx) return;
    setIsAnimating(true);
    setTimeout(() => {
      setActiveIdx(index);
      setIsAnimating(false);
    }, 300);
  };

  useEffect(() => {
    if (isHovered) return;
    const interval = setInterval(handleNext, 5000);
    return () => clearInterval(interval);
  }, [handleNext, isHovered]);

  return (
    <section className="py-24 bg-[#0a0a0f] relative overflow-hidden">
      {/* Background Decorative Element */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#7f5af0]/5 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-1.5 rounded-full glass border-white/5 text-[10px] font-bold tracking-[0.2em] text-[#00d4ff] uppercase mb-4">
            Testimonials
          </div>
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Their Words, Their Experiences</h2>
          <p className="text-white/60">Real transformations, no fake income claims.</p>
        </div>

        <div className="max-w-4xl mx-auto relative px-4 md:px-12">
          <div 
            className={`glass p-10 md:p-16 rounded-[50px] border-white/5 relative overflow-hidden min-h-[400px] flex flex-col justify-center transition-all duration-500 transform ${
              isAnimating ? 'opacity-0 scale-95' : 'opacity-100 scale-100'
            }`}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div className="absolute top-10 left-10 text-[#00d4ff]/10">
              <Quote className="w-20 h-20" />
            </div>
            
            <div className="flex gap-1 mb-8 relative">
              {[...Array(testimonials[activeIdx].rating)].map((_, i) => (
                <Star key={i} className="w-5 h-5 fill-[#00ff88] text-[#00ff88]" />
              ))}
            </div>

            <p className="text-xl md:text-3xl leading-relaxed mb-10 italic font-medium">
              "{testimonials[activeIdx].text}"
            </p>

            <div className="flex items-center gap-4 mt-auto">
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-[#00d4ff] to-[#7f5af0] p-0.5">
                <div className="w-full h-full rounded-full bg-[#0a0a0f] flex items-center justify-center font-bold text-lg text-white">
                  {testimonials[activeIdx].name.charAt(0)}
                </div>
              </div>
              <div>
                <p className="font-bold text-xl">{testimonials[activeIdx].name}</p>
                <p className="text-sm text-white/40">{testimonials[activeIdx].loc}</p>
              </div>
              <div className="ml-auto hidden sm:flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#00ff88]/10 text-[#00ff88] text-[10px] font-bold border border-[#00ff88]/20 tracking-wider">
                <Star className="w-3 h-3 fill-[#00ff88]" /> VERIFIED STORY
              </div>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="absolute inset-y-0 -left-2 md:-left-6 flex items-center">
            <button 
              onClick={handlePrev}
              disabled={isAnimating}
              className="w-12 h-12 glass rounded-full flex items-center justify-center hover:bg-white/10 transition-all border-white/10 shadow-xl group disabled:opacity-50"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-6 h-6 group-hover:-translate-x-0.5 transition-transform" />
            </button>
          </div>
          <div className="absolute inset-y-0 -right-2 md:-right-6 flex items-center">
            <button 
              onClick={handleNext}
              disabled={isAnimating}
              className="w-12 h-12 glass rounded-full flex items-center justify-center hover:bg-white/10 transition-all border-white/10 shadow-xl group disabled:opacity-50"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-6 h-6 group-hover:translate-x-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* Progress Indicators */}
        <div className="flex justify-center gap-3 mt-12">
          {testimonials.map((_, i) => (
            <button 
              key={i} 
              onClick={() => handleDotClick(i)}
              className={`h-2 rounded-full transition-all duration-500 ${
                activeIdx === i 
                  ? 'w-10 bg-[#00d4ff] shadow-[0_0_10px_rgba(0,212,255,0.5)]' 
                  : 'w-2 bg-white/20 hover:bg-white/40'
              }`} 
              aria-label={`Go to testimonial ${i + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
