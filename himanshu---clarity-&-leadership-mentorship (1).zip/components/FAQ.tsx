
import React, { useState } from 'react';
import { Plus, Minus } from 'lucide-react';

export const FAQ: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs = [
    {
      q: "Is this mentorship free?",
      a: "The initial webinar and consultation are completely free. If you choose to pursue further one-on-one mentorship, those details will be discussed separately — there is absolutely no obligation."
    },
    {
      q: "Is there an income guarantee?",
      a: "No. No genuine business can guarantee specific income results. Success depends entirely on your own effort, learning, and consistency. I provide the framework and guidance for you to succeed."
    },
    {
      q: "I'm already in network marketing; can I still join?",
      a: "Absolutely. Many of my mentees are already in the industry but lack a clear system or direction. My guidance is open to everyone, whether you're brand new or experienced."
    },
    {
      q: "How much time commitment is required?",
      a: "This depends on your specific goals. Initially, dedicating 1-2 hours daily for learning and implementation is recommended. As you grow, you can adjust your pace accordingly."
    },
    {
      q: "Which company are you associated with?",
      a: "I am associated with Forever Living Products. However, my focus is not on selling you the company, but on teaching you the business model and systems that lead to success."
    },
    {
      q: "What if it's not the right fit for me?",
      a: "That's perfectly fine. Attend the webinar to gain clarity. If you feel this path isn't right for you, there is no pressure at all. The decision is entirely yours."
    }
  ];

  return (
    <section id="faq" className="py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Frequently Asked Questions</h2>
          <p className="text-white/60">Find clarity on common questions and concerns.</p>
        </div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((f, i) => (
            <div key={i} className="glass rounded-[32px] border-white/5 overflow-hidden">
              <button 
                onClick={() => setOpenIdx(openIdx === i ? null : i)}
                className="w-full flex items-center justify-between p-8 text-left hover:bg-white/5 transition-colors"
              >
                <span className="font-bold text-lg md:text-xl pr-8">{f.q}</span>
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center flex-shrink-0">
                  {openIdx === i ? <Minus className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
                </div>
              </button>
              {openIdx === i && (
                <div className="px-8 pb-8 text-white/60 leading-relaxed animate-fade-in">
                  <div className="pt-4 border-t border-white/5">
                    {f.a}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
