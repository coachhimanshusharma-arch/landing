
import React from 'react';

export const Story: React.FC = () => {
  const milestones = [
    {
      title: "Small Town Beginning",
      desc: "Started in a small town with no business background or shortcuts. Only curiosity and a willingness to learn.",
      year: "2019",
      icon: "🏠"
    },
    {
      title: "Struggle Phase",
      desc: "The first two years were full of confusion. Guidance wasn't clear, and people focused only on selling rather than understanding.",
      year: "2020",
      icon: "😓"
    },
    {
      title: "Mindset Shift",
      desc: "When I shifted my focus from selling to solving problems, everything started to change for the better.",
      year: "2021",
      icon: "💡"
    },
    {
      title: "Systems & Leadership",
      desc: "Learned modern tools, mastered team building, and grew consistently to the manager level.",
      year: "2023",
      icon: "📈"
    },
    {
      title: "Global Exposure",
      desc: "Bali, Singapore — global exposure changes everything. Now I help others find the same clarity I found.",
      year: "2025",
      icon: "🌍"
    }
  ];

  return (
    <section id="journey" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">My Story, Your Path</h2>
          <p className="text-white/60 max-w-2xl mx-auto">From confusion to clarity, this is how my journey unfolded over the years.</p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          {/* Central Line */}
          <div className="absolute left-[30px] md:left-1/2 top-0 bottom-0 w-[2px] bg-gradient-to-b from-[#00d4ff] via-[#7f5af0] to-transparent" />

          {milestones.map((m, idx) => (
            <div key={idx} className={`relative flex items-center mb-16 md:mb-24 last:mb-0 ${
              idx % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
            }`}>
              {/* Content Card */}
              <div className={`w-full md:w-[45%] pl-16 md:pl-0 ${
                idx % 2 === 0 ? 'md:pr-12' : 'md:pl-12'
              }`}>
                <div className="glass p-8 rounded-3xl border-white/5 hover:border-[#00d4ff]/30 transition-all hover:scale-[1.02] relative group">
                  <div className="text-4xl mb-4">{m.icon}</div>
                  <div className="text-[#00d4ff] text-sm font-bold tracking-widest mb-2">{m.year}</div>
                  <h3 className="text-xl font-bold mb-3">{m.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{m.desc}</p>
                  
                  {/* Glowing Arrow for Tablet+ */}
                  <div className={`hidden md:block absolute top-1/2 -translate-y-1/2 w-4 h-4 glass border-white/5 rotate-45 z-[-1] ${
                    idx % 2 === 0 ? '-right-2' : '-left-2'
                  }`} />
                </div>
              </div>

              {/* Dot */}
              <div className="absolute left-[30px] md:left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 rounded-full glass border-[#00d4ff]/50 flex items-center justify-center z-10 shadow-[0_0_20px_rgba(0,212,255,0.4)]">
                <div className="w-3 h-3 rounded-full bg-[#00d4ff] animate-pulse" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
