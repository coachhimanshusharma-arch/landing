
import React from 'react';

export const Transformation: React.FC = () => {
  return (
    <section className="py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Journey of Growth</h2>
          <p className="text-white/60">Growth is visible when the process is right. Authenticity matters.</p>
        </div>

        <div className="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="glass p-1 rounded-3xl border-white/5 relative group overflow-hidden">
             <div className="absolute top-6 left-6 z-10 px-4 py-2 rounded-xl bg-black/60 backdrop-blur-md text-xs font-bold border border-white/10 uppercase tracking-widest">
                2019: Learning Phase
             </div>
             <img 
               src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&q=80&w=800" 
               className="w-full aspect-[4/5] object-cover rounded-[22px] opacity-50 grayscale group-hover:grayscale-0 transition-all duration-700" 
               alt="Before"
             />
             <div className="p-8">
                <h4 className="font-bold text-xl mb-2">Then: Simple Lifestyle</h4>
                <p className="text-sm text-white/40">Local exposure, early uncertainty, but a strong drive to learn and grow.</p>
             </div>
          </div>

          <div className="glass p-1 rounded-3xl border-white/5 relative group overflow-hidden bg-gradient-to-br from-[#00d4ff]/10 to-transparent">
             <div className="absolute top-6 left-6 z-10 px-4 py-2 rounded-xl bg-[#00d4ff] text-black text-xs font-bold uppercase tracking-widest">
                2025: Leading Phase
             </div>
             <img 
               src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80&w=800" 
               className="w-full aspect-[4/5] object-cover rounded-[22px] group-hover:scale-105 transition-transform duration-700" 
               alt="After"
             />
             <div className="p-8">
                <h4 className="font-bold text-xl mb-2 text-[#00d4ff]">Now: Global Mentorship</h4>
                <p className="text-sm text-white/40">International travel, stage presence, and leading a growing community of global aspirants.</p>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};
