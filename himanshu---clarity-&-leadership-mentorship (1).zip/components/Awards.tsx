
import React from 'react';
import { Trophy, Award, ScrollText, Medal, ArrowRight } from 'lucide-react';

export const Awards: React.FC = () => {
  const awards = [
    { title: "Manager Level Recognition", icon: Trophy, desc: "Achieved consistently through high growth metrics." },
    { title: "Leadership Excellence", icon: Award, desc: "Awarded for exceptional mentorship and team success." },
    { title: "Stage Performance", icon: Medal, desc: "Recognized at national annual conventions." },
    { title: "Certified Business Guide", icon: ScrollText, desc: "Official verification of professional coaching expertise." }
  ];

  return (
    <section className="py-24 relative overflow-hidden bg-gradient-to-t from-black to-[#0a0a0f]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Recognition Comes From Consistency</h2>
          <p className="text-white/60">Awards are the result, not the goal. Staying focused on the process is everything.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 max-w-5xl mx-auto">
          {awards.map((a, i) => (
            <div key={i} className="glass p-8 rounded-3xl border-white/5 flex flex-col items-center text-center hover:bg-white/5 transition-all group">
              <div className="w-16 h-16 rounded-full bg-[#7f5af0]/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <a.icon className="w-8 h-8 text-[#7f5af0]" />
              </div>
              <h3 className="font-bold text-sm md:text-base mb-2">{a.title}</h3>
              <p className="text-[10px] md:text-xs text-white/40 uppercase tracking-tighter">{a.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-20 flex justify-center">
          <div className="glass p-2 rounded-3xl border-white/5 max-w-4xl w-full flex flex-col md:flex-row gap-4">
             <div className="md:w-1/3 aspect-video bg-white/5 rounded-2xl animate-pulse" />
             <div className="md:w-1/3 aspect-video bg-white/5 rounded-2xl animate-pulse" />
             <div className="md:w-1/3 aspect-video bg-white/5 rounded-2xl animate-pulse" />
          </div>
        </div>

        <div className="mt-20 text-center">
          <a 
            href="#join" 
            className="inline-flex items-center gap-3 px-10 py-5 rounded-2xl bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] text-black font-bold text-xl shadow-[0_10px_40px_-10px_rgba(0,212,255,0.4)] hover:shadow-[0_0_30px_rgba(0,212,255,0.6),0_0_60px_rgba(127,90,240,0.4)] hover:scale-[1.03] active:scale-95 transition-all duration-300 group relative overflow-hidden"
          >
            <span className="relative z-10">Ready to achieve your own success?</span>
            <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform relative z-10" />
            <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none" />
          </a>
        </div>
      </div>
    </section>
  );
};
