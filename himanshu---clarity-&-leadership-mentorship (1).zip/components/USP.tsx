
import React from 'react';
import { Target, MessageSquare, Monitor, Ban, Hourglass, UserCheck } from 'lucide-react';

export const USP: React.FC = () => {
  const points = [
    {
      icon: Target,
      title: "Clarity First",
      desc: "Understanding before action. Know the path before you walk it — so you can move with confidence.",
      num: "01"
    },
    {
      icon: MessageSquare,
      title: "Simple Language",
      desc: "I explain complex concepts in plain, simple language to eliminate all confusion.",
      num: "02"
    },
    {
      icon: Monitor,
      title: "Modern Systems",
      desc: "Funnels, webinars, and digital tools — leaving outdated door-to-door methods behind.",
      num: "03"
    },
    {
      icon: Ban,
      title: "No Fake Promises",
      desc: "No flashy income screenshots, just genuine guidance and real, applicable skills.",
      num: "04"
    },
    {
      icon: Hourglass,
      title: "Long-Term Mindset",
      desc: "We don't chase quick money; we build sustainable growth and passive assets.",
      num: "05"
    },
    {
      icon: UserCheck,
      title: "Personal Branding",
      desc: "Learn to build your own brand. Our goal goes far beyond just recruitment.",
      num: "06"
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Different Approach, Clear Results</h2>
          <p className="text-white/60">Six pillars that make my mentorship unique and effective.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {points.map((p, i) => (
            <div key={i} className="group relative glass p-10 rounded-[40px] border-white/5 hover:border-[#00d4ff]/30 transition-all hover:-translate-y-2">
              <div className="absolute top-8 right-10 text-4xl font-heading font-bold text-white/5 group-hover:text-[#00d4ff]/10 transition-colors">
                {p.num}
              </div>
              <div className="w-14 h-14 rounded-2xl bg-white/5 flex items-center justify-center mb-8 group-hover:bg-[#00d4ff]/10 transition-colors">
                <p.icon className="w-7 h-7 text-[#00d4ff]" />
              </div>
              <h3 className="text-2xl font-bold mb-4 font-heading">{p.title}</h3>
              <p className="text-white/50 leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
