
import React from 'react';
import { ArrowDown, AlertCircle } from 'lucide-react';

export const Process: React.FC = () => {
  const steps = [
    { title: "LEARN", icon: "📚", desc: "Understand the foundation. Learn the business model clearly without any hype." },
    { title: "BUILD", icon: "🧠", desc: "Develop your skills. Implement modern mentorship methods." },
    { title: "APPLY", icon: "🎯", desc: "Take real-world actions with guidance. Automate your systems for efficiency." },
    { title: "GROW", icon: "📈", desc: "Advance consistently. Lead your team with a long-term, sustainable mindset." }
  ];

  return (
    <section className="py-24 relative overflow-hidden bg-[#0a0a0f]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Simple Process, Clear Growth</h2>
          <p className="text-white/60">Success is a sequence, not a coincidence.</p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {steps.map((s, i) => (
            <div key={i} className="flex flex-col items-center">
              <div className="w-full flex items-center gap-6 glass p-8 rounded-[40px] border-white/5 relative group hover:border-[#00d4ff]/20 transition-all">
                <div className="hidden md:flex absolute -left-12 top-1/2 -translate-y-1/2 w-10 h-10 glass rounded-full items-center justify-center font-bold text-[#00d4ff]">
                  {i+1}
                </div>
                <div className="text-5xl">{s.icon}</div>
                <div>
                  <h3 className="text-xl font-bold mb-2 font-heading tracking-widest text-[#00d4ff]">{s.title}</h3>
                  <p className="text-white/60">{s.desc}</p>
                </div>
              </div>
              {i < steps.length - 1 && (
                <div className="py-4">
                  <ArrowDown className="w-6 h-6 text-white/20 animate-bounce" />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-20 max-w-2xl mx-auto glass p-8 rounded-3xl border-orange-500/20 bg-orange-500/5">
          <div className="flex gap-4">
            <AlertCircle className="w-6 h-6 text-orange-400 flex-shrink-0" />
            <div>
              <p className="font-bold text-orange-400 mb-2">IMPORTANT NOTE</p>
              <ul className="grid grid-cols-2 gap-2 text-sm text-white/60">
                <li>• No Shortcuts</li>
                <li>• No Guarantees</li>
                <li>• No Pressure</li>
                <li>• Genuine Guidance Only</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
