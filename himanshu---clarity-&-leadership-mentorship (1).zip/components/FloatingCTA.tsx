
import React from 'react';
import { ArrowRight } from 'lucide-react';

export const FloatingCTA: React.FC = () => {
  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 z-40 md:hidden animate-slide-up">
      <a 
        href="#join"
        className="flex items-center justify-between w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] text-black font-bold shadow-[0_0_40px_rgba(0,212,255,0.4)]"
      >
        <span className="text-white">🚀 Start Your Journey Today</span>
        <ArrowRight className="w-5 h-5 text-white" />
      </a>
    </div>
  );
};
