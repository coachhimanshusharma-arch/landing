
import React, { useState } from 'react';
import { Send, CheckCircle2 } from 'lucide-react';

export const LeadForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    whatsapp: '',
    goal: 'Want to learn more'
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <section id="join" className="py-24 bg-[#0a0a0f]">
        <div className="container mx-auto px-6">
          <div className="max-w-xl mx-auto glass p-16 rounded-[40px] border-[#00ff88]/20 text-center animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-[#00ff88]/10 flex items-center justify-center mx-auto mb-8">
              <CheckCircle2 className="w-10 h-10 text-[#00ff88]" />
            </div>
            <h2 className="text-3xl font-bold mb-4 font-heading">Thank You!</h2>
            <p className="text-white/60 mb-8 leading-relaxed">
              Your form has been submitted successfully. I or my team will contact you on WhatsApp within the next 24 hours.
            </p>
            <button 
              onClick={() => setSubmitted(false)}
              className="text-[#00d4ff] font-bold text-sm hover:underline"
            >
              Fill out another form?
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="join" className="py-24 bg-[#0a0a0f]">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row gap-16 items-center">
          <div className="md:w-1/2">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 font-heading">Let's Connect</h2>
            <p className="text-lg text-white/60 mb-10 leading-relaxed">
              If you're serious about gaining clarity and receiving genuine guidance, please fill out this form. No false promises, just an honest conversation about your potential.
            </p>
            <div className="space-y-6">
               <div className="flex items-start gap-4">
                  <div className="w-10 h-10 glass rounded-xl flex items-center justify-center text-[#00d4ff] flex-shrink-0">1</div>
                  <p className="text-white/80">Submit your basic details using the form below.</p>
               </div>
               <div className="flex items-start gap-4">
                  <div className="w-10 h-10 glass rounded-xl flex items-center justify-center text-[#7f5af0] flex-shrink-0">2</div>
                  <p className="text-white/80">Receive a personal message on WhatsApp from me or my team.</p>
               </div>
               <div className="flex items-start gap-4">
                  <div className="w-10 h-10 glass rounded-xl flex items-center justify-center text-[#00ff88] flex-shrink-0">3</div>
                  <p className="text-white/80">Schedule a 1-on-1 discovery call to see if we're a good fit.</p>
               </div>
            </div>
          </div>

          <div className="md:w-1/2 w-full">
            <form onSubmit={handleSubmit} className="glass p-10 rounded-[40px] border-white/10 relative">
              <div className="space-y-6 mb-10">
                <div>
                  <label className="block text-xs font-bold text-white/40 uppercase tracking-widest mb-2 ml-1">Your Full Name</label>
                  <input 
                    required
                    type="text" 
                    placeholder="e.g. John Smith"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-[#00d4ff]/50 transition-colors"
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-white/40 uppercase tracking-widest mb-2 ml-1">WhatsApp Number</label>
                  <div className="relative">
                    <span className="absolute left-6 top-1/2 -translate-y-1/2 text-white/40">+</span>
                    <input 
                      required
                      type="tel" 
                      placeholder="Country Code + Number"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-12 text-white focus:outline-none focus:border-[#00d4ff]/50 transition-colors"
                      value={formData.whatsapp}
                      onChange={e => setFormData({...formData, whatsapp: e.target.value})}
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-bold text-white/40 uppercase tracking-widest mb-2 ml-1">Your Primary Goal</label>
                  <select 
                    className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 px-6 text-white focus:outline-none focus:border-[#00d4ff]/50 transition-colors appearance-none"
                    value={formData.goal}
                    onChange={e => setFormData({...formData, goal: e.target.value})}
                  >
                    <option className="bg-[#1a1a2e]">Want to learn more</option>
                    <option className="bg-[#1a1a2e]">Already in NM, need guidance</option>
                    <option className="bg-[#1a1a2e]">Interested in joining the team</option>
                    <option className="bg-[#1a1a2e]">Just exploring</option>
                  </select>
                </div>
                <div className="flex items-start gap-3 ml-1">
                  <input required type="checkbox" className="mt-1" />
                  <p className="text-[10px] text-white/40 leading-relaxed uppercase font-bold">
                    I agree to receive personalized business guidance via WhatsApp/Email. My data is handled securely.
                  </p>
                </div>
              </div>

              <button 
                type="submit"
                className="w-full py-5 rounded-2xl bg-white text-black font-bold text-lg flex items-center justify-center gap-3 hover:bg-[#00d4ff] hover:text-black transition-all group"
              >
                🚀 Submit & Connect
                <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
