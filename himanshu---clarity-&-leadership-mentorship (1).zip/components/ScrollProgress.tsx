
import React, { useState, useEffect } from 'react';

export const ScrollProgress: React.FC = () => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollY = window.scrollY;
      const scrollPercent = (scrollY / (documentHeight - windowHeight)) * 100;
      setProgress(scrollPercent);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="fixed top-0 left-0 w-full h-[4px] z-[60] bg-white/5 backdrop-blur-sm overflow-hidden">
      {/* CSS Animation for the shimmer effect */}
      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes shimmer-move {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(200%); }
        }
      `}} />

      <div 
        className="h-full bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] relative transition-[width] duration-300 ease-out shadow-[0_0_15px_rgba(0,212,255,0.5)]" 
        style={{ width: `${progress}%` }}
      >
        {/* Shimmer Overlay */}
        <div 
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent"
          style={{ 
            animation: 'shimmer-move 2s linear infinite',
            width: '200%'
          }} 
        />

        {/* Glowing Head of the bar */}
        <div className="absolute right-0 top-0 h-full w-20 bg-gradient-to-r from-transparent to-white/40 blur-sm" />
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-2 h-2 bg-white rounded-full blur-[2px] shadow-[0_0_10px_#fff] opacity-80" />
        <div className="absolute right-[-10px] top-1/2 -translate-y-1/2 w-6 h-6 bg-[#00d4ff] rounded-full blur-md opacity-30 animate-pulse" />
      </div>
    </div>
  );
};
