
import React from 'react';
import { Play, Star, Users, Globe } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 overflow-hidden">
      {/* Background Glows */}
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-[#7f5af0] rounded-full blur-[120px] opacity-20" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-[#00d4ff] rounded-full blur-[120px] opacity-20" />

      <div className="container mx-auto px-6 flex flex-col items-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass border-white/10 text-xs font-semibold text-[#00d4ff] mb-8 animate-fade-in">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00ff88] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#00ff88]"></span>
          </span>
          LEARN SYSTEMS, NOT JUST RECRUITING
        </div>

        {/* Headline */}
        <h1 className="font-heading text-4xl md:text-6xl lg:text-7xl font-bold text-center leading-[1.1] mb-6 max-w-4xl">
          From Small Town To <span className="bg-clip-text text-transparent bg-gradient-to-r from-[#00d4ff] to-[#7f5af0]">Global Mindset</span>
        </h1>
        
        <p className="text-lg md:text-xl text-white/60 text-center max-w-2xl mb-12">
          5+ years of experience, bridging the gap from local beginnings to international exposure — providing the clarity I wish I had when I started.
        </p>

        {/* Video Placeholder */}
        <div className="relative w-full max-w-4xl aspect-video rounded-3xl overflow-hidden glass border-white/10 mb-12 group cursor-pointer shadow-2xl">
          <img 
            src="https://images.unsplash.com/photo-1515187029135-18ee286d815b?auto=format&fit=crop&q=80&w=1600" 
            alt="Himanshu Mentorship"
            className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-20 h-20 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md border border-white/20 group-hover:scale-110 transition-all shadow-[0_0_40px_rgba(0,212,255,0.3)]">
              <Play className="w-8 h-8 fill-[#00d4ff] text-[#00d4ff] ml-1" />
            </div>
          </div>
          <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
            <span className="text-sm font-medium text-white/80">WATCH: My Journey & Philosophy</span>
            <span className="text-xs px-2 py-1 rounded bg-black/40 backdrop-blur-md">1:45</span>
          </div>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 w-full max-w-md mb-16">
          <a 
            href="#join" 
            className="flex-1 py-4 px-8 rounded-2xl bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] text-center font-bold text-lg shadow-[0_0_40px_rgba(0,212,255,0.4)] hover:scale-105 transition-all"
          >
            🚀 Start Your Journey
          </a>
          <a 
            href="#webinar" 
            className="flex-1 py-4 px-8 rounded-2xl glass border-white/10 text-center font-bold text-lg hover:bg-white/5 transition-all"
          >
            📺 Join Free Training
          </a>
        </div>

        {/* Trust Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 w-full max-w-4xl border-t border-white/5 pt-12">
          <div className="flex items-center gap-4 group">
            <div className="p-3 rounded-xl bg-white/5 group-hover:bg-[#00d4ff]/10 transition-colors">
              <Star className="w-6 h-6 text-[#00d4ff]" />
            </div>
            <div>
              <p className="font-bold">5+ Years</p>
              <p className="text-xs text-white/40 uppercase tracking-widest">Experience</p>
            </div>
          </div>
          <div className="flex items-center gap-4 group">
            <div className="p-3 rounded-xl bg-white/5 group-hover:bg-[#7f5af0]/10 transition-colors">
              <Users className="w-6 h-6 text-[#7f5af0]" />
            </div>
            <div>
              <p className="font-bold">100+ People</p>
              <p className="text-xs text-white/40 uppercase tracking-widest">Mentored</p>
            </div>
          </div>
          <div className="flex items-center gap-4 group">
            <div className="p-3 rounded-xl bg-white/5 group-hover:bg-[#00ff88]/10 transition-colors">
              <Globe className="w-6 h-6 text-[#00ff88]" />
            </div>
            <div>
              <p className="font-bold">Global Exposure</p>
              <p className="text-xs text-white/40 uppercase tracking-widest">Bali & Singapore</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
