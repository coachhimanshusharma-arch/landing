
import React, { useState, useEffect } from 'react';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'py-3' : 'py-6'
    }`}>
      <div className="container mx-auto px-6">
        <div className={`flex items-center justify-between glass rounded-2xl px-6 py-3 transition-all duration-300 ${
          isScrolled ? 'shadow-[0_0_20px_rgba(0,0,0,0.5)] border-white/10' : 'bg-transparent border-transparent'
        }`}>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#00d4ff] to-[#7f5af0]" />
            <span className="font-heading font-bold text-xl tracking-tight">HIMANSHU</span>
          </div>
          
          <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
            <a href="#journey" className="hover:text-white transition-colors">Journey</a>
            <a href="#philosophy" className="hover:text-white transition-colors">Philosophy</a>
            <a href="#webinar" className="hover:text-white transition-colors">Webinar</a>
            <a href="#faq" className="hover:text-white transition-colors">FAQ</a>
          </nav>

          <a 
            href="#join" 
            className="px-6 py-2 rounded-full bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] text-sm font-bold shadow-[0_0_20px_rgba(0,212,255,0.3)] hover:scale-105 transition-all"
          >
            Join Now
          </a>
        </div>
      </div>
    </header>
  );
};
