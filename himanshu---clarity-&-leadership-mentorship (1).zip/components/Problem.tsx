
import React from 'react';
import { HelpCircle, AlertTriangle, ShieldX, TrendingDown } from 'lucide-react';

export const Problem: React.FC = () => {
  const problems = [
    {
      icon: HelpCircle,
      title: "Confusion",
      desc: "Network marketing feels confusing, often hidden behind too much hype.",
      color: "border-orange-500/20 shadow-orange-500/5"
    },
    {
      icon: AlertTriangle,
      title: "Wrong Guidance",
      desc: "Following incorrect methods taught by those seeking shortcuts.",
      color: "border-red-500/20 shadow-red-500/5"
    },
    {
      icon: ShieldX,
      title: "Pressure Selling",
      desc: "Feeling uncomfortable about forcing products or opportunities on others.",
      color: "border-pink-500/20 shadow-pink-500/5"
    },
    {
      icon: TrendingDown,
      title: "No Results",
      desc: "Putting in the hard work but lacking a clear, proven direction.",
      color: "border-yellow-500/20 shadow-yellow-500/5"
    }
  ];

  return (
    <section className="py-24 bg-black/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Does This Sound Like You?</h2>
          <p className="text-white/60">You are not alone. Many are stuck in this same frustrating cycle.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {problems.map((p, idx) => (
            <div key={idx} className={`glass p-8 rounded-3xl border transition-all hover:-translate-y-2 ${p.color}`}>
              <div className="mb-6 inline-block p-4 rounded-2xl bg-white/5">
                <p.icon className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-3">{p.title}</h3>
              <p className="text-white/50 text-sm leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <p className="text-xl font-heading text-[#7f5af0] italic">
            "I was exactly where you are 5 years ago... but everything changed."
          </p>
        </div>
      </div>
    </section>
  );
};
