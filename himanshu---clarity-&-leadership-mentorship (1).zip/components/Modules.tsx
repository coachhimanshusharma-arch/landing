
import React from 'react';
import { BookOpen, Brain, Users, Crown, Settings, TrendingUp, Lock } from 'lucide-react';

export const Modules: React.FC = () => {
  const modules = [
    {
      icon: BookOpen,
      title: "Foundation & Mindset",
      points: ["Core understanding", "Common myths busted", "Managing expectations"],
      module: "MODULE 1"
    },
    {
      icon: Brain,
      title: "Business Model Clarity",
      points: ["How it actually works", "Income streams explained", "Simplified concepts"],
      module: "MODULE 2"
    },
    {
      icon: Users,
      title: "Trust-Based Building",
      points: ["No pressure tactics", "Relationship-first approach", "Building a legacy"],
      module: "MODULE 3"
    },
    {
      icon: Crown,
      title: "Leadership Skills",
      points: ["Effective team leadership", "Communication mastery", "Mentoring others"],
      module: "MODULE 4"
    },
    {
      icon: Settings,
      title: "Modern Systems",
      points: ["Digital funnel setup", "Automated webinars", "Personal brand building"],
      module: "MODULE 5"
    },
    {
      icon: TrendingUp,
      title: "Step-by-Step Growth",
      points: ["Weekly action plans", "Performance tracking", "Scaling your reach"],
      module: "MODULE 6"
    }
  ];

  return (
    <section className="py-24 bg-black/40">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-2xl">
            <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">What You Will Learn</h2>
            <p className="text-white/60">My mentorship covers these core areas step-by-step to ensure complete clarity.</p>
          </div>
          <div className="glass px-6 py-3 rounded-full border-white/10 text-sm font-semibold flex items-center gap-3">
            <span className="w-2 h-2 rounded-full bg-[#00ff88]" />
            CURRICULUM UPDATED FOR 2025
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {modules.map((m, i) => (
            <div key={i} className="glass p-8 rounded-3xl border-white/5 group hover:border-[#7f5af0]/30 transition-all flex flex-col">
              <div className="flex items-center justify-between mb-8">
                <div className="p-4 rounded-2xl bg-white/5 group-hover:bg-[#7f5af0]/10 transition-colors">
                  <m.icon className="w-6 h-6 text-[#7f5af0]" />
                </div>
                <span className="text-xs font-bold text-white/30 tracking-widest">{m.module}</span>
              </div>
              <h3 className="text-xl font-bold mb-6 font-heading">{m.title}</h3>
              <ul className="space-y-4 flex-grow mb-8">
                {m.points.map((p, pi) => (
                  <li key={pi} className="flex items-center gap-3 text-sm text-white/60">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#7f5af0]" />
                    {p}
                  </li>
                ))}
              </ul>
              <div className="pt-6 border-t border-white/5 flex items-center justify-between opacity-40">
                <span className="text-xs uppercase tracking-tighter">Lesson Available</span>
                <Lock className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 flex flex-col items-center">
          <a 
            href="#webinar" 
            className="px-10 py-5 rounded-2xl bg-[#7f5af0] font-bold text-lg shadow-[0_0_30px_rgba(127,90,240,0.3)] hover:scale-105 transition-all"
          >
            📺 Join Free Webinar to Preview
          </a>
        </div>
      </div>
    </section>
  );
};
