
import React from 'react';
import { MessageCircle } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  return (
    <a 
      href="https://wa.me/91XXXXXXXXXX" 
      target="_blank" 
      rel="noopener noreferrer"
      className="fixed bottom-24 right-6 md:bottom-10 md:right-10 z-50 w-16 h-16 rounded-full bg-[#00ff88] text-black flex items-center justify-center shadow-[0_0_30px_rgba(0,255,136,0.5)] hover:scale-110 transition-all animate-pulse-subtle group"
    >
      <MessageCircle className="w-8 h-8" />
      <div className="absolute -top-12 right-0 glass px-4 py-2 rounded-xl text-xs font-bold border-white/10 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap hidden md:block">
        Chat with Himanshu
      </div>
    </a>
  );
};
