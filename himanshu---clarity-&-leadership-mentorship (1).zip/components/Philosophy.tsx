
import React from 'react';
import { XCircle, CheckCircle2, Quote } from 'lucide-react';

export const Philosophy: React.FC = () => {
  return (
    <section id="philosophy" className="py-24 bg-gradient-to-b from-black to-[#0a0a0f]">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold mb-4 font-heading">Network Marketing Isn't Wrong</h2>
          <p className="text-xl text-[#00d4ff] font-heading">— The Approach Is</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto mb-20">
          {/* Column NOT */}
          <div className="glass p-8 md:p-12 rounded-[40px] border-red-500/10 shadow-[0_0_50px_rgba(239,68,68,0.05)]">
            <h3 className="flex items-center gap-3 text-red-400 font-bold text-2xl mb-8">
              <XCircle className="w-6 h-6" /> WHAT IT'S NOT
            </h3>
            <ul className="space-y-6">
              {[
                "Get-rich-quick scheme / Shortcuts",
                "Pressure selling to friends & family",
                "Fake motivation & Stage shouting",
                "Randomly chasing strangers",
                "Flashing income screenshots"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 text-white/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400/30 mt-2 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Column IS */}
          <div className="glass p-8 md:p-12 rounded-[40px] border-[#00ff88]/10 shadow-[0_0_50px_rgba(0,255,136,0.05)]">
            <h3 className="flex items-center gap-3 text-[#00ff88] font-bold text-2xl mb-8">
              <CheckCircle2 className="w-6 h-6" /> WHAT IT ACTUALLY IS
            </h3>
            <ul className="space-y-6">
              {[
                "Skill-based long-term business",
                "Leadership & Communication growth",
                "System-driven consistent workflow",
                "Trust-based relationship building",
                "Genuine problem solving"
              ].map((item, i) => (
                <li key={i} className="flex items-start gap-4 text-white/80">
                  <CheckCircle2 className="w-5 h-5 text-[#00ff88] mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="max-w-3xl mx-auto">
          <div className="relative glass p-10 md:p-16 rounded-[40px] border-white/5 overflow-hidden group">
            <div className="absolute -top-10 -right-10 opacity-5 group-hover:opacity-10 transition-opacity">
              <Quote className="w-40 h-40" />
            </div>
            <p className="text-2xl md:text-4xl font-heading font-medium leading-relaxed text-center mb-8 relative z-10">
              "Success is not about selling products — it's about solving problems and building people."
            </p>
            <div className="flex flex-col items-center">
              <div className="w-16 h-1 bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] rounded-full mb-4" />
              <p className="font-heading font-bold text-xl">— Himanshu</p>
              <p className="text-white/40 text-sm">Manager & Leadership Mentor</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
