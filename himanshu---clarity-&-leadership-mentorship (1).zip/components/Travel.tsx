
import React from 'react';
import { Plane, MapPin, Camera } from 'lucide-react';

export const Travel: React.FC = () => {
  const images = [
    {
      url: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&q=80&w=800",
      title: "Bali, Indonesia",
      desc: "Mindset Expansion 2025"
    },
    {
      url: "https://images.unsplash.com/photo-1525625239513-4422b512d35e?auto=format&fit=crop&q=80&w=800",
      title: "Singapore City",
      desc: "Global Exposure Tour"
    },
    {
      url: "https://images.unsplash.com/photo-1506461883276-594a12b11cf3?auto=format&fit=crop&q=80&w=800",
      title: "Leader's Meet",
      desc: "International Recognition"
    }
  ];

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row gap-12 items-center mb-20">
          <div className="md:w-1/2">
            <h2 className="text-3xl md:text-5xl font-bold mb-6 font-heading">Exposure Changes Your Thinking</h2>
            <p className="text-white/60 mb-8 leading-relaxed">
              My international travel in 2025 completely shifted my perspective. When you see the world outside and meet new people, your dreams naturally grow bigger.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-4 glass p-4 rounded-2xl border-white/5">
                <Plane className="w-6 h-6 text-[#00d4ff]" />
                <span className="text-sm">International Travel: Bali & Singapore</span>
              </div>
              <div className="flex items-center gap-4 glass p-4 rounded-2xl border-white/5">
                <MapPin className="w-6 h-6 text-[#7f5af0]" />
                <span className="text-sm">Global Perspective & Networking</span>
              </div>
            </div>
          </div>
          
          <div className="md:w-1/2 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="aspect-[3/4] rounded-3xl overflow-hidden glass border-white/5 group relative">
                <img src={images[0].url} alt="Bali" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                  <p className="font-bold">{images[0].title}</p>
                  <p className="text-xs text-white/60">{images[0].desc}</p>
                </div>
              </div>
              <div className="aspect-square rounded-3xl overflow-hidden glass border-white/5 flex items-center justify-center p-8 bg-gradient-to-br from-[#00d4ff]/10 to-transparent">
                <Camera className="w-12 h-12 text-[#00d4ff] opacity-40" />
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="aspect-square rounded-3xl overflow-hidden glass border-white/5 group relative">
                <img src={images[2].url} alt="Award" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                  <p className="font-bold">{images[2].title}</p>
                  <p className="text-xs text-white/60">{images[2].desc}</p>
                </div>
              </div>
              <div className="aspect-[3/4] rounded-3xl overflow-hidden glass border-white/5 group relative">
                <img src={images[1].url} alt="Singapore" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex flex-col justify-end p-6">
                  <p className="font-bold">{images[1].title}</p>
                  <p className="text-xs text-white/60">{images[1].desc}</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto glass p-8 md:p-12 rounded-[40px] border-white/5 relative group">
          <div className="flex flex-col md:flex-row gap-8 items-center text-center md:text-left">
            <div className="text-5xl">💡</div>
            <div>
              <p className="text-xl md:text-2xl font-medium leading-relaxed mb-4">
                "Travel isn't just about the photos. It's about new people, new ideas, and new perspectives — exposure is the key to growth."
              </p>
              <p className="text-[#00d4ff] font-heading font-bold">— KEY INSIGHT</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
