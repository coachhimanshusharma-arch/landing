
import React from 'react';
import { Instagram, Youtube, Mail, MessageCircle } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="pt-24 pb-12 bg-black border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-r from-[#00d4ff] to-[#7f5af0]" />
              <span className="font-heading font-bold text-xl tracking-tight">HIMANSHU</span>
            </div>
            <p className="text-white/40 text-sm leading-relaxed mb-6">
              Empowering individuals with clarity, systems, and leadership-driven growth since 2019. Small-town roots with a global perspective.
            </p>
            <div className="flex gap-4">
               <a href="#" className="w-10 h-10 glass rounded-xl flex items-center justify-center hover:bg-[#00d4ff]/20 transition-all text-[#00d4ff]">
                 <Instagram className="w-5 h-5" />
               </a>
               <a href="#" className="w-10 h-10 glass rounded-xl flex items-center justify-center hover:bg-red-500/20 transition-all text-red-500">
                 <Youtube className="w-5 h-5" />
               </a>
               <a href="#" className="w-10 h-10 glass rounded-xl flex items-center justify-center hover:bg-[#00ff88]/20 transition-all text-[#00ff88]">
                 <MessageCircle className="w-5 h-5" />
               </a>
               <a href="#" className="w-10 h-10 glass rounded-xl flex items-center justify-center hover:bg-white/10 transition-all text-white/40">
                 <Mail className="w-5 h-5" />
               </a>
            </div>
          </div>

          <div>
            <h4 className="font-bold mb-6 font-heading uppercase text-xs tracking-widest text-[#00d4ff]">Quick Links</h4>
            <ul className="space-y-4 text-sm text-white/40">
              <li><a href="#" className="hover:text-white transition-colors">About Himanshu</a></li>
              <li><a href="#journey" className="hover:text-white transition-colors">Journey Timeline</a></li>
              <li><a href="#webinar" className="hover:text-white transition-colors">Free Masterclass</a></li>
              <li><a href="#join" className="hover:text-white transition-colors">Connect / Join Team</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 font-heading uppercase text-xs tracking-widest text-[#7f5af0]">Legal</h4>
            <ul className="space-y-4 text-sm text-white/40">
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms & Conditions</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Earnings Disclaimer</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Refund Policy</a></li>
            </ul>
          </div>

          <div className="glass p-6 rounded-3xl border-white/5 bg-white/5">
             <h4 className="font-bold mb-4 font-heading text-xs tracking-widest">⚠️ DISCLAIMER</h4>
             <p className="text-[10px] text-white/30 leading-relaxed uppercase">
                Results vary based on individual effort, learning, and consistency. No specific income guarantees are made. This is not a get-rich-quick scheme. Real success requires time, dedication, and proper implementation of proven systems.
             </p>
          </div>

        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-white/20 text-xs font-medium">
            © 2025 Himanshu. All Rights Reserved.
          </p>
          <p className="text-white/20 text-xs flex items-center gap-2">
            Made with <span className="text-red-500">❤️</span> in India
          </p>
        </div>
      </div>
    </footer>
  );
};
