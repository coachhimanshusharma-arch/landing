
import React, { useState, useEffect } from 'react';
import { Calendar, Clock, User, CheckCircle } from 'lucide-react';

export const Webinar: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({ days: 2, hours: 14, mins: 35, secs: 22 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.secs > 0) return { ...prev, secs: prev.secs - 1 };
        if (prev.mins > 0) return { ...prev, mins: prev.mins - 1, secs: 59 };
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="webinar" className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-[#7f5af0]/10 via-transparent to-[#00d4ff]/10" />
      
      <div className="container mx-auto px-6 relative">
        <div className="max-w-6xl mx-auto glass p-8 md:p-16 rounded-[60px] border-white/10 shadow-[0_0_80px_rgba(127,90,240,0.15)] overflow-hidden">
          <div className="flex flex-col lg:flex-row gap-16">
            
            <div className="lg:w-1/2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-red-500 text-white text-[10px] font-bold tracking-widest mb-6 animate-pulse">
                🔴 LIVE MASTERCLASS
              </div>
              <h2 className="text-3xl md:text-5xl font-bold mb-6 font-heading leading-tight">
                The Truth About Network Marketing — <span className="text-[#00d4ff]">Live Session</span>
              </h2>
              <p className="text-lg text-white/60 mb-10 leading-relaxed">
                Join Himanshu for a 60-minute deep dive into the business model that changed his life. No fluff, no motivation — just systems.
              </p>

              <div className="space-y-6 mb-10">
                {[
                  "The actual reality of network marketing",
                  "Common mistakes that 95% of people make",
                  "The right approach for system-based growth",
                  "Live Q&A session with Himanshu"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-4">
                    <CheckCircle className="w-6 h-6 text-[#00ff88]" />
                    <span className="text-white/80">{item}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-wrap gap-4 mb-10">
                <div className="glass px-6 py-4 rounded-2xl border-white/5 flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-[#00d4ff]" />
                  <div>
                    <p className="text-[10px] text-white/40 uppercase font-bold">DATE</p>
                    <p className="font-bold">Next Sunday</p>
                  </div>
                </div>
                <div className="glass px-6 py-4 rounded-2xl border-white/5 flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#7f5af0]" />
                  <div>
                    <p className="text-[10px] text-white/40 uppercase font-bold">TIME</p>
                    <p className="font-bold">7:00 PM IST</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:w-1/2 flex flex-col items-center justify-center">
              <div className="w-full relative aspect-square max-w-[400px] mb-12 group">
                <div className="absolute inset-0 bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] rounded-[60px] blur-[40px] opacity-20 group-hover:opacity-40 transition-opacity" />
                <img 
                  src="https://images.unsplash.com/photo-1475721027785-f74eccf877e2?auto=format&fit=crop&q=80&w=800" 
                  className="relative w-full h-full object-cover rounded-[60px] border-2 border-white/10" 
                  alt="Himanshu Live"
                />
              </div>

              <div className="grid grid-cols-4 gap-4 w-full max-w-[400px] mb-8">
                {[
                  { label: "Days", val: timeLeft.days },
                  { label: "Hrs", val: timeLeft.hours },
                  { label: "Min", val: timeLeft.mins },
                  { label: "Sec", val: timeLeft.secs }
                ].map((t, i) => (
                  <div key={i} className="glass p-4 rounded-2xl text-center border-white/5">
                    <p className="text-2xl font-bold font-heading">{String(t.val).padStart(2, '0')}</p>
                    <p className="text-[10px] text-white/40 uppercase font-bold">{t.label}</p>
                  </div>
                ))}
              </div>

              <a 
                href="#join" 
                className="w-full max-w-[400px] py-5 rounded-2xl bg-gradient-to-r from-[#00d4ff] to-[#7f5af0] text-center font-bold text-xl shadow-[0_0_50px_rgba(0,212,255,0.4)] hover:scale-105 transition-all mb-4"
              >
                🎯 Reserve My Free Seat
              </a>
              <p className="text-sm text-white/40 flex items-center gap-2">
                <User className="w-4 h-4" /> 234 people already registered
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
